//Criando uma variável para fazer a requisição dos módulos
let mysql = require('mysql');

//Criando uma conexão
let conexao = mysql.createConnection({
    //Criando as variáveis de conexão do banco de dados
    host: "localhost",
    user: "root",
    password: "",
    database: "nodejs"
});

//Utilizando a passagem de parâmetros através da variável con
   conexao.connect(function(err) {
    if(err)throw err;
    console.log("Conectado");
     //Criando a inserção de registros na tabela de consumidores
     let sql = `insert into consumidores values(${nome}, 'Rua Henrique', 150)`;
     const values = [customer.nome, customer.endereco];
     conexao.query(sql, function(err, result) {
        if(err) throw err;
        console.log("1 Registro inserido com êxito!");
         
     })



   });
   const people = [
    {
        name: "Rita",
        address: "Rua Fábia, 100",
    },
    {
        name: "Ana",
        address: "Rua Catão, 902"
    },
    {
        name: "Nicole",
        address: "Rua Taipas, 920"
    },
    {
        name: "Romulo",
        address: "Rua das Cruzes, 100"
    }
];

people.forEach(person => {

    let sql = `insert into consumidores values ('${person.name}','${person.address}')`
        
        connection.query(sql, (err, result) => {
            if (err) { throw err };
            console.log("Registro inserido com sucesso!");
        });
    });



    // Criando uma variável para fazer a requesição dos módulos
let mysql=require('mysql');

//Criando uma conexão 
let con = mysql.createConnection({
    // Criando as variáveis de conexão no Banco de Dados
    host:"localhost",
    user:"root",
    password:"",
    database:"nodejs"
});

// Utilizando a passagem de parâmetros através da variável con 
con.connect(function(err){
    if(err)throw err;
    console.log("Conectado");
    //Criando a inserção de registros no tabela de consumidores
    let sql ="insert into consumidores values ('Ricardo Alexandre','Rua Atibaia, 449')";
    con.query(sql,function(err,result){
        if(err)throw err;
        console.log("1 Registro inserido com Êxito");

    })


});