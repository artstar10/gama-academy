// Criando uma variável para fazer a requesição dos módulos
let mysql=require('mysql');

//Criando uma conexão 
let con = mysql.createConnection({
    // Criando as variáveis de conexão no Banco de Dados
    host:"localhost",
    user:"root",
    password:"",
    database:"nodejs"

});

// Utilizando a passagem de parâmetros através da variável con 
con.connect(function(err){
    if(err)throw err;
    //Criando um Update do registro desejado
    let sql="update consumidores set nome_consumidor='Romulo Andrade da Silva' where nome_consumidor='Romulo de Andrade'";
    con.query(sql,function(err, result){

        if(err)throw err;
        console.log(result.affectedRows+"Registro modificado");
    });
    
});