//Crriando uma variável para a chamada da requisição do nosso http
let http = require('http');

//Criando um serviço para levantar a nossa página
http.createServer(function (req,res){
    res.writeHead(200,{'Content-Type':'text/html'});
    res.end("<h1>Subindo a nossa primeira página com NodeJS</h1>");

}).listen(8075);