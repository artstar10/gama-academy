//Criando uma variável para receber o HTTP
let http = require('http');
//Criando uma nova variável para atribuir o conteúdo de uma página em html
let fs = require('fs');
//Criando uma variável para receber o conteúdo da página que foi chamada
let conteudo = fs.readFileSync('index.html');

//Subindo o nosso serviço com NodeJS
http.createServer(function(req,res){
    //res.end("<h3>Seja bem vindo ao Servico com NodeJS</h3>");
    res.end(conteudo);

}).listen(8075);